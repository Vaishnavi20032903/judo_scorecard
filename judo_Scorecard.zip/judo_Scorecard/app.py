from flask import Flask, request, jsonify, send_file, render_template
import openpyxl, os
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side

app = Flask(__name__)
EXCEL_FILE = "matches.xlsx"
FORM_FILE = "matches_form.xlsx"

# ✅ All fields (unchanged)
ALL_FIELDS = [
    "WeightCategory","Gender","Date","Mat","Obs","Number","Code",
    "White_Name","White_Ctry","White_IPP","White_WAZ","White_SHIDO",
    "White_XH3_WAZ","White_XH3_SHIDO",
    "White_GS","White_GS_IPP","White_GS_WAZ","White_GS_SHIDO",
    "White_GS_XH3_IPP","White_GS_XH3_WAZ","White_GS_XH3_SHIDO","White_GS_Big",
    "Blue_Name","Blue_Ctry","Blue_IPP","Blue_WAZ","Blue_SHIDO",
    "Blue_XH3_WAZ","Blue_XH3_SHIDO",
    "Blue_GS","Blue_GS_IPP","Blue_GS_WAZ","Blue_GS_SHIDO",
    "Blue_GS_XH3_IPP","Blue_GS_XH3_WAZ","Blue_GS_XH3_SHIDO","Blue_GS_Big",
    "Winner","Winner_Ctry","Score_Result",
    "Referee_Name","Referee_Ctry","Referee_City",
    "Judge1_Name","Judge1_Ctry","Judge1_City",
    "Judge2_Name","Judge2_Ctry","Judge2_City",
    "Signature_Rep_IJF","Signature_Rep_DELA","sig_IJF","sig_DELA"
]
for i in range(1,9):
    ALL_FIELDS += [f"White_Score_{i}", f"White_Tech_{i}", f"White_Time_{i}"]
for i in range(1,9):
    ALL_FIELDS += [f"Blue_Score_{i}", f"Blue_Tech_{i}", f"Blue_Time_{i}"]

# ✅ Styles for formatted sheet
border = Border(left=Side(style="thin"), right=Side(style="thin"),
                top=Side(style="thin"), bottom=Side(style="thin"))
header_fill = PatternFill("solid", fgColor="D9E1F2")
title_fill = PatternFill("solid", fgColor="FFD700")
col_fill = PatternFill("solid", fgColor="E5E5E5")

def styled_cell(ws, row, col, value, bold=False, fill=None, align="center"):
    cell = ws.cell(row=row, column=col, value=value)
    if bold: cell.font = Font(bold=True)
    if fill: cell.fill = fill
    if align == "center":
        cell.alignment = Alignment(horizontal="center", vertical="center")
    elif align == "left":
        cell.alignment = Alignment(horizontal="left", vertical="center")
    cell.border = border
    return cell

# ✅ Save formatted block for matches_form.xlsx
def save_formatted_block(data, match_no=None):
    if os.path.exists(FORM_FILE):
        wb = load_workbook(FORM_FILE)
        ws = wb.active
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = "Judo Matches Form"

    start_row = ws.max_row + 2 if ws.max_row > 1 else 1
    row = start_row

    # Title
    ws.merge_cells(start_row=row, start_column=2, end_row=row, end_column=8)
    styled_cell(ws, row, 2, f"🥋 Match {match_no or data.get('Number','')}", bold=True, fill=title_fill)
    row += 2

    # Match Info
    styled_cell(ws, row, 2, "Match Info", bold=True, fill=header_fill, align="left")
    row += 1
    headers = ["Weight","Gender","Date","Mat","Obs","Bout No","Code"]
    values = [data.get("WeightCategory",""), data.get("Gender",""), data.get("Date",""),
              data.get("Mat",""), data.get("Obs",""), data.get("Number",""), data.get("Code","")]
    for col, h in enumerate(headers, start=2):
        styled_cell(ws, row, col, h, bold=True, fill=col_fill)
    row += 1
    for col, v in enumerate(values, start=2):
        styled_cell(ws, row, col, v)
    row += 2

    # Players
    styled_cell(ws, row, 2, "White Player", bold=True, fill=header_fill, align="left")
    styled_cell(ws, row, 6, "Blue Player", bold=True, fill=header_fill, align="left")
    row += 1
    styled_cell(ws, row, 2, "Name", bold=True, fill=col_fill); styled_cell(ws, row, 3, data.get("White_Name",""))
    styled_cell(ws, row, 6, "Name", bold=True, fill=col_fill); styled_cell(ws, row, 7, data.get("Blue_Name",""))
    row += 1
    styled_cell(ws, row, 2, "Country", bold=True, fill=col_fill); styled_cell(ws, row, 3, data.get("White_Ctry",""))
    styled_cell(ws, row, 6, "Country", bold=True, fill=col_fill); styled_cell(ws, row, 7, data.get("Blue_Ctry",""))
    row += 2

    # Scores
    score_headers = ["IPP","WAZ","SHIDO","GS"]
    white_scores = [data.get("White_IPP",""), data.get("White_WAZ",""), data.get("White_SHIDO",""), data.get("White_GS","")]
    blue_scores = [data.get("Blue_IPP",""), data.get("Blue_WAZ",""), data.get("Blue_SHIDO",""), data.get("Blue_GS","")]
    for i,h in enumerate(score_headers, start=2): styled_cell(ws, row, i, h, bold=True, fill=col_fill)
    for i,v in enumerate(white_scores, start=2): styled_cell(ws, row+1, i, v)
    for i,h in enumerate(score_headers, start=6): styled_cell(ws, row, i, h, bold=True, fill=col_fill)
    for i,v in enumerate(blue_scores, start=6): styled_cell(ws, row+1, i, v)
    row += 3

    # Technical Scores
    styled_cell(ws, row, 2, "White Technical Scores", bold=True, fill=header_fill, align="left")
    styled_cell(ws, row, 6, "Blue Technical Scores", bold=True, fill=header_fill, align="left")
    row += 1
    for col, h in enumerate(["S","Tech","Time"], start=2): styled_cell(ws, row, col, h, bold=True, fill=col_fill)
    for col, h in enumerate(["S","Tech","Time"], start=6): styled_cell(ws, row, col, h, bold=True, fill=col_fill)
    row += 1
    for i in range(1,9):
        styled_cell(ws, row, 2, data.get(f"White_Score_{i}",""))
        styled_cell(ws, row, 3, data.get(f"White_Tech_{i}",""))
        styled_cell(ws, row, 4, data.get(f"White_Time_{i}",""))
        styled_cell(ws, row, 6, data.get(f"Blue_Score_{i}",""))
        styled_cell(ws, row, 7, data.get(f"Blue_Tech_{i}",""))
        styled_cell(ws, row, 8, data.get(f"Blue_Time_{i}",""))
        row += 1
    row += 1

    # Result
    styled_cell(ws, row, 2, "Result", bold=True, fill=header_fill, align="left")
    row += 1
    headers = ["Winner","Winner Country","Score"]
    values = [data.get("Winner",""), data.get("Winner_Ctry",""), data.get("Score_Result","")]
    for col,h in enumerate(headers, start=2): styled_cell(ws, row, col, h, bold=True, fill=col_fill)
    row += 1
    for col,v in enumerate(values, start=2): styled_cell(ws, row, col, v)
    row += 2

    # Officials
    styled_cell(ws, row, 2, "Officials", bold=True, fill=header_fill, align="left")
    row += 1
    officials = [
        ("Referee", data.get("Referee_Name",""), data.get("Referee_Ctry",""), data.get("Referee_City","")),
        ("Judge1", data.get("Judge1_Name",""), data.get("Judge1_Ctry",""), data.get("Judge1_City","")),
        ("Judge2", data.get("Judge2_Name",""), data.get("Judge2_Ctry",""), data.get("Judge2_City","")),
    ]
    for role,name,ctry,city in officials:
        styled_cell(ws, row, 2, role, bold=True, fill=col_fill)
        styled_cell(ws, row, 3, name)
        styled_cell(ws, row, 4, ctry)
        styled_cell(ws, row, 5, city)
        row += 1

    wb.save(FORM_FILE)
# ✅ Ensure workbook and headers
def ensure_workbook(path=EXCEL_FILE):
    if os.path.exists(path):
        wb = openpyxl.load_workbook(path)
        ws = wb.active
        existing = [ws.cell(1, col).value for col in range(1, len(ALL_FIELDS)+1)]
        if any(h is None for h in existing) or len(existing) != len(ALL_FIELDS):
            wb = Workbook()
            ws = wb.active
            ws.title = "Judo Matches"
            ws.append(ALL_FIELDS)
            wb.save(path)
            return wb, ws
        return wb, ws
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = "Judo Matches"
        ws.append(ALL_FIELDS)
        wb.save(path)
        return wb, ws

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add_match', methods=['POST'])
def add_match():
    data = request.json
    try:
        # Normal save
        if not os.path.exists(EXCEL_FILE):
            wb = Workbook()
            ws = wb.active
            ws.append(ALL_FIELDS)
            wb.save(EXCEL_FILE)
        wb = load_workbook(EXCEL_FILE)
        ws = wb.active
        ws.append([data.get(f, "") for f in ALL_FIELDS])
        wb.save(EXCEL_FILE)

        # Formatted save
        save_formatted_block(data, data.get("Number",""))

        return jsonify({"success": True, "message": "✅ Match saved in both Excel files!"})
    except Exception as e:
       return jsonify({"success": False, "message": "❌ please close Excel file before saving Data!!"})

@app.route('/get_matches', methods=['GET'])
def get_matches():
    if not os.path.exists(EXCEL_FILE):
        return jsonify({"rows": []})
    wb = load_workbook(EXCEL_FILE, data_only=True)
    ws = wb.active
    headers = [c.value for c in ws[1]]
    rows = []
    for r_idx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        obj = {"_row": r_idx}
        for h, v in zip(headers, row):
            obj[h or ""] = v
        rows.append(obj)
    return jsonify({"rows": rows})

@app.route('/update_match', methods=['POST'])
def update_match():
    data = request.get_json() or {}
    row_index = data.get("row_index")
    if row_index is None:
        return jsonify({"success": False, "message": "row_index required"}), 400
    wb, ws = ensure_workbook(EXCEL_FILE)
    try:
        row_index = int(row_index)
    except:
        return jsonify({"success": False, "message": "row_index must be integer"}), 400
    if row_index <= 1 or row_index > ws.max_row:
        return jsonify({"success": False, "message": "invalid row_index"}), 400
    try:
        for col, field in enumerate(ALL_FIELDS, start=1):
            ws.cell(row=row_index, column=col).value = data.get(field, "")
        match_no = ws.cell(row=row_index, column=6).value or data.get("Number","")
        wb.save(EXCEL_FILE)

        save_formatted_block(data, match_no)

        return jsonify({"success": True, "message": f"✏️ Row {row_index} updated in both files!"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)})

@app.route('/delete_match', methods=['POST'])
def delete_match():
    try:
        data = request.json
        row_index = int(data.get("row_index"))
        wb = load_workbook(EXCEL_FILE)
        ws = wb.active
        if row_index <= 1 or row_index > ws.max_row:
            return jsonify({"success": False, "message": "Invalid row index"})
        match_no = ws.cell(row=row_index, column=6).value
        ws.delete_rows(row_index)
        wb.save(EXCEL_FILE)

        # Remove from form file (basic block delete)
        if os.path.exists(FORM_FILE) and match_no:
            wb2 = load_workbook(FORM_FILE)
            ws2 = wb2.active
            for r in range(1, ws2.max_row+1):
                if str(ws2.cell(r, 2).value).startswith("🥋 Match") and str(match_no) in str(ws2.cell(r, 2).value):
                    ws2.delete_rows(r, 25)
                    break
            wb2.save(FORM_FILE)

        return jsonify({"success": True, "message": f"🗑️ Match {match_no} deleted from both files!"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)})

@app.route('/new_sheet', methods=['POST'])
def new_sheet():
    wb = Workbook()
    ws = wb.active
    ws.title = "Judo Matches"
    ws.append(ALL_FIELDS)
    wb.save(EXCEL_FILE)
    return jsonify({"success": True, "message": "🗒️ New sheet created"})

@app.route('/download', methods=['GET'])
def download():
    if os.path.exists(EXCEL_FILE):
        return send_file(EXCEL_FILE, as_attachment=True)
    return jsonify({"success": False, "message": "not found"}), 404

@app.route('/download_form', methods=['GET'])
def download_form():
    if os.path.exists(FORM_FILE):
        return send_file(FORM_FILE, as_attachment=True)
    return jsonify({"success": False, "message": "not found"}), 404

if __name__ == "__main__":
    app.run(debug=True)
