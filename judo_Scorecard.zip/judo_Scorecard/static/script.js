function showPopup(message, type="info") {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.className = "toast " + type;
  toast.style.display = "block";
  toast.style.top = "20px";

  setTimeout(() => {
    toast.style.top = "-60px";
    setTimeout(() => { toast.style.display = "none"; }, 500);
  }, 3000);
}

// ✅ Global response handler
function handleResponse(res, action="") {
  if (res.success) {
    if (action === "save") {
      showPopup(res.message || "✅ Match saved successfully in both files!", "success");
    } else if (action === "update") {
      showPopup(res.message || "✏️ Match updated successfully in both files!", "success");
    } else if (action === "delete") {
      showPopup(res.message || "🗑️ Match deleted successfully from both files!", "success");
    } else {
      showPopup(res.message, "success");
    }
  } else {
    showPopup(res.message || "❌ Something went wrong", "error");
  }
}

const ALL_FIELDS = [
  "WeightCategory","Gender","Date","Mat","Obs","Number","Code",
  "White_Name","White_Ctry","White_IPP","White_WAZ","White_SHIDO",
  "White_XH3_WAZ","White_XH3_SHIDO",
  "White_GS","White_GS_IPP","White_GS_WAZ","White_GS_SHIDO",
  "White_GS_XH3_IPP","White_GS_XH3_WAZ","White_GS_XH3_SHIDO","White_GS_Big",
  "Blue_Name","Blue_Ctry","Blue_IPP","Blue_WAZ","Blue_SHIDO",
  "Blue_XH3_WAZ","Blue_XH3_SHIDO",
  "Blue_GS","Blue_GS_IPP","Blue_GS_WAZ","Blue_GS_SHIDO",
  "Blue_GS_XH3_IPP","Blue_GS_XH3_WAZ","Blue_GS_XH3_SHIDO","Blue_GS_Big",
  "Winner","Winner_Ctry","Score_Result",
  "Referee_Name","Referee_Ctry","Referee_City",
  "Judge1_Name","Judge1_Ctry","Judge1_City",
  "Judge2_Name","Judge2_Ctry","Judge2_City",
  "Signature_Rep_IJF","Signature_Rep_DELA","sig_IJF","sig_DELA"
];
for(let i=1;i<=8;i++){ ALL_FIELDS.push(`White_Score_${i}`,`White_Tech_${i}`,`White_Time_${i}`); }
for(let i=1;i<=8;i++){ ALL_FIELDS.push(`Blue_Score_${i}`,`Blue_Tech_${i}`,`Blue_Time_${i}`); }

function addRow(containerId, prefix){
  const container = document.getElementById(containerId);
  const idx = container.querySelectorAll('tr').length + 1;
  const tr = document.createElement('tr');
  tr.innerHTML = `<td><input id="${prefix}_Score_${idx}" /></td>
                  <td><input id="${prefix}_Tech_${idx}" /></td>
                  <td><input id="${prefix}_Time_${idx}" /></td>
                  <td><button class="btn small" onclick="this.closest('tr').remove()">❌</button></td>`;
  container.appendChild(tr);
}

function resetRows(containerId, prefix){
  const container = document.getElementById(containerId);
  container.innerHTML = '';
  for(let i=0;i<3;i++) addRow(containerId, prefix);
}

function collectFormData(){
  const data = {};
  ALL_FIELDS.forEach(f=> data[f]='');
  document.querySelectorAll('[id]').forEach(el=>{
    if(el.type === 'file') return;
    if(el.tagName==='SELECT' || el.tagName==='INPUT' || el.tagName==='TEXTAREA') data[el.id] = el.value || '';
  });
  document.querySelectorAll('#whiteScores tr').forEach((tr,i)=>{
    data[`White_Score_${i+1}`] = tr.querySelector(`[id^="White_Score_"]`)?.value || '';
    data[`White_Tech_${i+1}`] = tr.querySelector(`[id^="White_Tech_"]`)?.value || '';
    data[`White_Time_${i+1}`] = tr.querySelector(`[id^="White_Time_"]`)?.value || '';
  });
  document.querySelectorAll('#blueScores tr').forEach((tr,i)=>{
    data[`Blue_Score_${i+1}`] = tr.querySelector(`[id^="Blue_Score_"]`)?.value || '';
    data[`Blue_Tech_${i+1}`] = tr.querySelector(`[id^="Blue_Tech_"]`)?.value || '';
    data[`Blue_Time_${i+1}`] = tr.querySelector(`[id^="Blue_Time_"]`)?.value || '';
  });
  const ijf = document.getElementById('sigPreviewIJF'); if(ijf && ijf.src) data['sig_IJF'] = ijf.src;
  const dela = document.getElementById('sigPreviewDELA'); if(dela && dela.src) data['sig_DELA'] = dela.src;
  return data;
}

async function saveMatch(){
  const payload = collectFormData();
  try{
    const res = await fetch('/add_match',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const j = await res.json();
    handleResponse(j, "save");
    if(j.success){ loadMatches(); }
  }catch(e){ showPopup('❌ Save failed','error'); }
}

async function loadMatches(){
  try{
    const res = await fetch('/get_matches');
    const j = await res.json();
    window.matchesCache = j.rows || [];
    renderMatches();
  }catch(e){ showPopup('❌ Failed loading','error'); }
}

let currentPage = 1; const pageSize = 6;
function renderMatches(){
  const out = document.getElementById('matchesList');
  out.innerHTML = '';
  const q = (document.getElementById('searchInput').value||'').toLowerCase();
  const list = (window.matchesCache||[]).filter(r=>{
    if(!r) return false;
    const fields = ['White_Name','Blue_Name','Number','White_Ctry','Blue_Ctry'];
    return fields.some(f=> (''+(r[f]||'')).toLowerCase().includes(q));
  });
  const pages = Math.max(1, Math.ceil(list.length/pageSize));
  if(currentPage>pages) currentPage=pages;
  const slice = list.slice((currentPage-1)*pageSize, currentPage*pageSize);
  slice.forEach(item=>{
    const div = document.createElement('div'); div.className='match-row';
    div.innerHTML = `<div class="match-info"><strong>${item['Number']||'—'} • ${item['Code']||''}</strong>
                     <div>White: ${item['White_Name']||'—'} — Blue: ${item['Blue_Name']||'—'}</div></div>`;
    const actions = document.createElement('div'); actions.className='match-actions';
    const ebtn = document.createElement('button'); ebtn.className='btn small'; ebtn.textContent='Edit'; ebtn.onclick = ()=> loadIntoForm(item);
    const dbtn = document.createElement('button'); dbtn.className='btn small danger'; dbtn.textContent='Del'; dbtn.onclick = ()=> doDelete(item._row);
    actions.appendChild(ebtn); actions.appendChild(dbtn);
    div.appendChild(actions); out.appendChild(div);
  });
  document.getElementById('pageInfo').textContent = `Page ${currentPage} / ${pages}`;
}

function loadIntoForm(item){
  ALL_FIELDS.forEach(f=>{
    const el = document.getElementById(f);
    if(el) el.value = item[f]||'';
  });
  resetRows('whiteScores','White'); resetRows('blueScores','Blue');
  for(let i=1;i<=8;i++){
    if(item[`White_Score_${i}`]||item[`White_Tech_${i}`]||item[`White_Time_${i}`]){
      addRow('whiteScores','White');
      const idx = document.querySelectorAll('#whiteScores tr').length;
      document.getElementById(`White_Score_${idx}`).value = item[`White_Score_${i}`]||'';
      document.getElementById(`White_Tech_${idx}`).value = item[`White_Tech_${i}`]||'';
      document.getElementById(`White_Time_${idx}`).value = item[`White_Time_${i}`]||'';
    }
    if(item[`Blue_Score_${i}`]||item[`Blue_Tech_${i}`]||item[`Blue_Time_${i}`]){
      addRow('blueScores','Blue');
      const idx = document.querySelectorAll('#blueScores tr').length;
      document.getElementById(`Blue_Score_${idx}`).value = item[`Blue_Score_${i}`]||'';
      document.getElementById(`Blue_Tech_${idx}`).value = item[`Blue_Tech_${i}`]||'';
      document.getElementById(`Blue_Time_${idx}`).value = item[`Blue_Time_${i}`]||'';
    }
  }
  if(item.sig_IJF) document.getElementById('sigPreviewIJF').src = item.sig_IJF;
  if(item.sig_DELA) document.getElementById('sigPreviewDELA').src = item.sig_DELA;
  window.selectedRow = item._row;
  showPopup(`✏️ Loaded row ${item._row}`,"info");
}

async function doDelete(row){
  if(!row){ showPopup('❌ Select a row first (Edit)', 'error'); return; }
  const confirmBox = document.getElementById("confirmBox");
  confirmBox.style.display = "block";

  return new Promise((resolve) => {
    document.getElementById("confirmYes").onclick = async () => {
      confirmBox.style.display = "none";
      const res = await fetch('/delete_match',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({row_index:row})
      });
      const j = await res.json();
      handleResponse(j, "delete");
      if(j.success){ loadMatches(); clearForm(); }
      resolve(true);
    };
    document.getElementById("confirmNo").onclick = () => {
      confirmBox.style.display = "none";
      showPopup('⚠️ Delete cancelled','warning');
      resolve(false);
    };
  });
}

async function doUpdate(){
  if(!window.selectedRow){ showPopup('❌ Load a row (Edit) to update','error'); return; }
  const payload = collectFormData(); payload.row_index = window.selectedRow;
  const res = await fetch('/update_match',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  const j = await res.json();
  handleResponse(j, "update");
  if(j.success){ loadMatches(); }
}

function clearForm(){
  document.querySelectorAll('[id]').forEach(el=>{
    if(el.tagName==='INPUT' || el.tagName==='SELECT' || el.tagName==='TEXTAREA') el.value='';
  });
  resetRows('whiteScores','White'); resetRows('blueScores','Blue');
  document.getElementById('sigPreviewIJF').removeAttribute('src'); 
  document.getElementById('sigPreviewDELA').removeAttribute('src');
  window.selectedRow = null;
  showPopup('🔄 Cleared',"info");
}

// ✅ Country search helper
function wireCountrySearch(inputId, selectId){
  const input = document.getElementById(inputId);
  const sel = document.getElementById(selectId);
  if(!input || !sel) return;
  input.addEventListener('input', ()=>{
    const q = input.value.toLowerCase().trim();
    const opts = [...sel.options];
    sel.innerHTML = '<option value=""></option>'; 
    opts.forEach(o=>{
      if(o.value.toLowerCase().includes(q)) sel.appendChild(o.cloneNode(true));
    });
  });
}

function wireEvents(){
  document.getElementById('addWhiteRow').addEventListener('click', ()=> addRow('whiteScores','White'));
  document.getElementById('addBlueRow').addEventListener('click', ()=> addRow('blueScores','Blue'));
  document.getElementById('resetWhite').addEventListener('click', ()=> resetRows('whiteScores','White'));
  document.getElementById('resetBlue').addEventListener('click', ()=> resetRows('blueScores','Blue'));
  document.getElementById('saveBtn').addEventListener('click', saveMatch);
  document.getElementById('updateBtn').addEventListener('click', doUpdate);
  document.getElementById('deleteBtn').addEventListener('click', ()=> doDelete(window.selectedRow));
  document.getElementById('clearBtn').addEventListener('click', clearForm);
  document.getElementById('searchBtn').addEventListener('click', ()=> { currentPage=1; renderMatches(); });
  document.getElementById('refreshBtn').addEventListener('click', loadMatches);
  document.getElementById('prevPage').addEventListener('click', ()=> { if(currentPage>1){ currentPage--; renderMatches(); } });
  document.getElementById('nextPage').addEventListener('click', ()=> { currentPage++; renderMatches(); } );
  document.getElementById('downloadBtn').addEventListener('click', ()=> { window.location='/download'; } );
  document.getElementById('downloadFormBtn').addEventListener('click', ()=> {  window.location='/download_form'; });
  document.getElementById('newSheetBtn').addEventListener('click', async ()=> { if(!confirm('Create new empty sheet?')) return; await fetch('/new_sheet',{method:'POST'}); loadMatches(); showPopup('🗒️ New sheet',"success"); } );

  populateCountrySelects().then(()=>{
    wireCountrySearch('whiteCountrySearch','White_Ctry');
    wireCountrySearch('blueCountrySearch','Blue_Ctry');
    wireCountrySearch('winnerCountrySearch','Winner_Ctry');
    wireCountrySearch('refCountrySearch','Referee_Ctry');
    wireCountrySearch('judge1CountrySearch','Judge1_Ctry');
    wireCountrySearch('judge2CountrySearch','Judge2_Ctry');
  });

  // ✅ Dark mode toggle
  const toggleBtn = document.getElementById("themeToggle");
  if(toggleBtn){
    toggleBtn.addEventListener("click", () => {
      document.body.classList.toggle("dark");
      toggleBtn.textContent = document.body.classList.contains("dark") ? "☀️" : "🌙";
    });
  }
}

document.addEventListener('DOMContentLoaded', ()=>{
  wireEvents(); 
  resetRows('whiteScores','White'); 
  resetRows('blueScores','Blue'); 
  loadMatches();
});

// ✅ Country loader
async function populateCountrySelects(){
  const fallbackCountries = [
    "Afghanistan","Albania","Algeria","Andorra","Angola","Argentina","Armenia",
    "Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Belgium",
    "Bhutan","Bolivia","Bosnia","Brazil","Bulgaria","Cambodia","Cameroon","Canada",
    "Chile","China","Colombia","Costa Rica","Croatia","Cuba","Cyprus","Czech Republic",
    "Denmark","Dominican Republic","Ecuador","Egypt","Estonia","Ethiopia","Finland",
    "France","Georgia","Germany","Ghana","Greece","Hungary","Iceland","India",
    "Indonesia","Iran","Iraq","Ireland","Israel","Italy","Jamaica","Japan","Jordan",
    "Kazakhstan","Kenya","Kuwait","Latvia","Lebanon","Lithuania","Luxembourg",
    "Madagascar","Malaysia","Maldives","Malta","Mexico","Moldova","Monaco","Mongolia",
    "Montenegro","Morocco","Nepal","Netherlands","New Zealand","Nigeria","North Korea",
    "Norway","Oman","Pakistan","Panama","Paraguay","Peru","Philippines","Poland",
    "Portugal","Qatar","Romania","Russia","Saudi Arabia","Serbia","Singapore","Slovakia",
    "Slovenia","South Africa","South Korea","Spain","Sri Lanka","Sudan","Sweden",
    "Switzerland","Syria","Taiwan","Tajikistan","Tanzania","Thailand","Tunisia","Turkey",
    "Uganda","Ukraine","United Arab Emirates","United Kingdom","United States","Uruguay",
    "Uzbekistan","Venezuela","Vietnam","Yemen","Zambia","Zimbabwe"
  ];

  try{
    const res = await fetch('https://restcountries.com/v3.1/all');
    if (!res.ok) throw new Error("API failed");
    const countries = await res.json();
    var countryList = countries.map(c => c.name.common).filter(c=>c).sort();
  }catch(e){
    console.warn("⚠️ Using fallback country list:", e.message);
    var countryList = fallbackCountries;
  }

  document.querySelectorAll('select.country-select').forEach(sel=>{
    const placeholder = sel.querySelector("option[disabled]");
    const placeholderText = placeholder ? placeholder.outerHTML : '<option value="" disabled selected>-- Select Country --</option>';
    sel.innerHTML = placeholderText;

    countryList.forEach(name=>{
      const opt = document.createElement('option'); 
      opt.value = name; 
      opt.textContent = name;
      sel.appendChild(opt);
    });
  });
}
