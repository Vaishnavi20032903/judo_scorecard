
Judo Match Tracker 

How to run:
go to commandline and 
  1. pip install -r requirements.txt
  2. python app.py
  go to browser :
  1. Open http://127.0.0.1:5000/
